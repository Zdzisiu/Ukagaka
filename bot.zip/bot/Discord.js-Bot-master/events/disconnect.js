module.exports = client => {
  console.log(`You have been disconnected at ${new Date()}`);
};
