module.exports = {
	name: 'wha',
	description: 'List of all commands',
	usage: '',
	cooldown: 5,
	execute(message, args) {
		const data = [];
		const { commands } = message.client;

		message.channel.send('here you go bro:');
		message.channel.send(commands.map(command => '`' + command.name + ':` ' + command.description + ' *' + command.usage + '*').join('\n'));
	} };