const Discord = require('discord.js');
const randomPuppy = require('random-puppy');
const customisation = require('../customisation.json');

module.exports = {
	name: 'send',
	description: 'Sends a random image from a subreddit',
	usage: 'send [subreddit]',
	execute(message, args) {
		randomPuppy(args)
			.then(url => {
				const embed = new Discord.RichEmbed()
					.setImage(url)
					.setColor('#ff9900')
				return message.channel.send({ embed });
			});
	} };