const Discord = require('discord.js')
const client = new Discord.Client()
var insult = ["you're a limp dick jabroni","stop being a wet sock","you assweed","you're as thick as manure and only half as useful","You're so ugly that you're a coronavirus repellent"]

client.on('ready', () => {
    client.user.setActivity("Being a limp dick jabroni")
})

client.on('message', (receivedMessage) => {
    if (receivedMessage.author == client.user) {
        return
    }

    if (receivedMessage.content.includes(client.user.toString())) {
        // Send acknowledgement message
        receivedMessage.channel.send("Message received from " +
            receivedMessage.author.toString() + ": " + receivedMessage.content)
    }
    
    if (receivedMessage.content.startsWith("bruh")) {
        processCommand(receivedMessage)
    }
    
});

function random(mn, mx) {  
    return Math.random() * (mx - mn) + mn;  
}

function processCommand(receivedMessage) {
    let fullCommand = receivedMessage.content.substr(5) // Remove the leading exclamation mark
    let splitCommand = fullCommand.split(" ") // Split the message up in to pieces for each space
    let primaryCommand = splitCommand[0] // The first word directly after the exclamation is the command
    let arguments = splitCommand.slice(1) // All other words are arguments/parameters/options for the command

    console.log("Command received: " + primaryCommand)
    console.log("Arguments: " + arguments) // There may not be any arguments

    if (primaryCommand == "wha") {
        helpCommand(arguments, receivedMessage)
    }else if (primaryCommand == "insult") {
        insultCommand(arguments, receivedMessage)
    }else{
        receivedMessage.channel.send("I don't understand the command. Try `bruh wha` for commands")
    }
}

function helpCommand(arguments, receivedMessage) {
        receivedMessage.channel.send("Here they come: `wha`: lists commands")
}

function insultCommand(arguments, receivedMessage) {
    receivedMessage.channel.send(arguments+" "+insult[Math.floor(random(1, 5))-1])
}

client.login("NjkxMDQ2NDkwNjM3OTkxOTc2.XnaSQg.Aj-Zcsc2Qt4Kg_bZurIUqDyiAco")