const uniqueRandomArray = require('unique-random-array');

const insult = uniqueRandomArray(['you\'re a limp dick jabroni', 'stop being a wet sock', 'you assweed', 'you\'re as thick as manure and only half as useful', 'you\'re so ugly that you\'re a coronavirus repellent', 'you\'re a turtle egg',
	'may the devil make a ladder of your back bones while picking apples in the garden of hell!', 'I hope you get fucked by a fish', 'you fucking pillock', 'you\'re a wanker', 'you\'re an uphill gardener',
	'you\'re a fopdoodle', 'you\'re an ape covered in human flesh', 'you are like a dog with two dicks', 'you\'re a cumberworld', 'jebiesz jeże', ' your face is just fine but we’ll have to put a bag over that personality.',
	'you\'re bad at wearing shoes', 'you\'re a cuntsandwich', 'you\'re  a microwaved sardine', 'you\'re an chromosome hoarder', 'you\'re a little bitch chicken', 'you\'re a twaterang', 'you\'re International Cock Eater',
	'you\'re a slimy monkey', 'you\'re a cuntzilla', 'you\'re a chickenfucker', 'you\'re a bitchzilla', 'you\'re a shitweasel', 'you\'re a sausage-masseuse', 'you\'re a thundercunt', 'you Dyslexic Hotpocket',
	'you Cell Scaling Network Baiting Switch', 'May your wife give birth to a centipede so you have to work for shoes all your life', 'fuck your ancestors to the eighteenth generation', 'bitch']);

function random(mn, mx) {
	return Math.random() * (mx - mn) + mn;
}

module.exports = {
	usage: 'insult [user]',
	name: 'insult',
	description: 'what do you expect you assweed?',
	execute(message, args) {
		if (!message.mentions.users.size) {
			message.reply('WHo tHe FucK shoUld I InsUlt');
			message.channel.send('GiVe ME NaMez');
			return message.channel.send('BiTch');
		}
		else {
			const taggedUser = message.mentions.users.first();

			message.channel.send(taggedUser.username + ' ' + insult());
		}
	},
};